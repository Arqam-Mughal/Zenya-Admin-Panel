<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{env('APP_NAME')}} - @yield('title')</title>
    <link rel="stylesheet" href="{{ asset('admin/css/main.css') }}">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.min.css">

</head>

<body>
    @include('admin.layout.sidebar')

    @yield('content')
    
    <script src="{{ asset('admin/js/main.js') }}"></script>
</body>

</html>